//
//  ViewController.swift
//  Switch
//
//  Created by Rp on 28/11/18.
//  Copyright © 2018 Rp. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var sw : UISwitch!
    
    let sw1 = UISwitch()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        sw.isOn = true
        
        sw1.isOn = false
        sw1.tintColor = UIColor.red
        sw1.thumbTintColor = UIColor.green
        sw1.onTintColor = UIColor.yellow
        sw1.frame = CGRect.init(x: 20, y: 100, width: 60, height: 25)
        sw1.addTarget(self, action: #selector(clickHere), for: .valueChanged)
        view.addSubview(sw1)
    }
    
    @IBAction func clickon(sw:UISwitch){
        if sw.isOn{
            
        }else{
            
        }
    }
    
    @objc func clickHere(){
        if sw1.isOn{
            
        }else{
            
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

